package com.example.pignol_lafarge.android

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.pignol_lafarge.android.WeatherResponse


@Composable
fun WeatherScreen(weatherResponse: WeatherResponse) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Météo à ${weatherResponse.name}")
        Text(text = "Température: ${weatherResponse.main.temp}°C")
        Text(text = "Humidité: ${weatherResponse.main.humidity}%")
        Text(text = "Vitesse du vent: ${weatherResponse.wind.speed} m/s")
    }
}