package com.example.pignol_lafarge.android

import android.net.http.HttpResponseCache.install
import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.features.json.*
import io.ktor.client.features.json.serializer.*
import io.ktor.client.request.*
import io.ktor.client.features.logging.*

object WeatherApiClient {
    private val client = HttpClient() {
        install(JsonFeature) {
            serializer = KotlinxSerializer()
        }
        install(Logging) {
            logger = Logger.DEFAULT
            level = LogLevel.INFO
        }
    }

    suspend fun fetchWeather(cityName: String): WeatherResponse {
        return client.get("https://api.openweathermap.org/data/2.5/weather") {
            parameter("q", cityName)
            parameter("appid", "7515a0aee27e9f71154316a53da362ba")
            parameter("units", "metric") // Pour obtenir la température en Celsius
        }
    }
}

